import asyncio

from scripts.settings import *
from scripts.classes.game_class import Game


# pygbag entry point: the render loop lives in Game.play(), which is async and
# yields to the browser once per frame. The original desktop main.pyw structure
# is preserved otherwise.
async def main():
    while True:
        game = Game()
        await game.play()
        q = game.end_screen()
        if q == "quit":
            break
    pg.quit()


asyncio.run(main())
